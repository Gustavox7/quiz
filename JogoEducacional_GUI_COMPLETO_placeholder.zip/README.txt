O executável será adicionado aqui em breve.
Este é o pacote final do jogo educacional GUI com mascotes, som e painel do professor.